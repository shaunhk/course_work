def add(first_number, second_number)
  return first_number + second_number
end

def pop_dens(pop, area)
  return "#{pop / area} people per square chicken."
end

p add(2, 3)
p pop_dens(5373000, 77933)
