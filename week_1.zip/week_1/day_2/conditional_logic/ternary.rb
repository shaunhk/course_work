score = 6

result = score > 5 ? "pass" : "fail"

p result
