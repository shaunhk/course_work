score = 6

result = "fail"
result = "pass" if (score >= 6)

p result
