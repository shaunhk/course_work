puts "When was Ruby made?"
input = gets.chomp.downcase

puts (input == "1995" ? "right" : "wrong")
