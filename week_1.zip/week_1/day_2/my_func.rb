def greet(name, time_of_day)
  return "A good #{time_of_day}, to you, #{name.capitalize}."
end

p greet("COLIN", "afternoon")
# def another_greet()
#   return words
# end
#
# p another_greet()
