pocketmoney = {"Ann" => 22, "Sophie" => "£25", "Gerry" => "€423"}
p pocketmoney
pocketmoney["Joe"] = 53531
p pocketmoney
pocketmoney.delete("Sophie")
p pocketmoney
pocketmoney["Ann"] = 200
p pocketmoney
