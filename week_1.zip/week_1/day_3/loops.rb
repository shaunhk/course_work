counter = 0
my_num = 5

while (counter < my_num)
  p "Counter is #{counter}"
  counter += 1
  p "---"
end
