class Action
  def self.all
    return ["ate", 
            "chased", 
            "nibbled", 
            "drooled on", 
            "chewed on", 
            "fried"]
  end
end